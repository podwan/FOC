#ifndef __MOTOR_H
#define __MOTOR_H

#include "userMain.h"
#include "encoder.h"

 extern Encoder encoder;
#endif
