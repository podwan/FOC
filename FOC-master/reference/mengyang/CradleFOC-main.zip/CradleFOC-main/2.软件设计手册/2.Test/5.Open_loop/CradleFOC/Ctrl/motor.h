//
// Created by User on 2024/4/30.
//

#ifndef CRADLEFOC_MOTOR_H
#define CRADLEFOC_MOTOR_H

void open_velocity_test1(float velocity);

#endif //CRADLEFOC_MOTOR_H
