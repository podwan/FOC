#ifndef __MT6701_H
#define __MT6701_H

float MT6701_GetRawAngle(void);

#endif
