#ifndef __MT6701_H
#define __MT6701_H

#endif
