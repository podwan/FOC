#ifndef __Serial_H
#define __Serial_H

#include <stdio.h>

int fputc(int ch, FILE *f);

#endif
