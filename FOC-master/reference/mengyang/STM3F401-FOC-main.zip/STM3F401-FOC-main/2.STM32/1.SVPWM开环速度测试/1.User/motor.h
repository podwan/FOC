#ifndef __MOTOR_H
#define __MOTOR_H

void OpenVelocity(float target); // 开环运行测试

#endif
