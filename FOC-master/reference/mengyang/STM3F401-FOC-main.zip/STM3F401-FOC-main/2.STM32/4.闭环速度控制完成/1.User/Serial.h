#ifndef __Serial_H
#define __Serial_H

#include <stdio.h>

void FOC_log(const char *format, ...); // UART DMA模式发送数据

#endif
